package com.example.AdministratorDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdministratorDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
